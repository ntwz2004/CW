# TRAFFIC LIGHTS > 2024-10-31 7:26pm
https://universe.roboflow.com/zeynep-ujznh/traffic-lights-ddncr

Provided by a Roboflow user
License: CC BY 4.0

